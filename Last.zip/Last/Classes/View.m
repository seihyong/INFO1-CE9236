//
//  View.m
//  Last
//
//  Created by SEI-HYONG PARK on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import	"ViewController.h"

//five buttons in the UIActionSheet
enum {
	actionDestruct,
	actionQE3,
	actionEvacuate,
	actionNothing,
	actionCancel
};

@implementation View


- (id)initWithFrame:(CGRect)frame controller: (ViewController *) c{
    
    self = [super initWithFrame:frame];
    if (self) {
		
		viewController = c;		
		
		if (viewController.title == @"2008"){
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"lehman.jpg"]];
		} else if (viewController.title == @"2009") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"stimulus.jpg"]];			
		} else if (viewController.title == @"2010") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"rally.png"]];			
		} else if (viewController.title == @"2011") {
			self.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed: @"repeat.png"]];			
		} else {
			self.backgroundColor = [UIColor blackColor];
		}

		if(viewController.title == @"2011"){
			[NSTimer scheduledTimerWithTimeInterval: 0
											 target: self
										   selector: @selector(showActionSheet:)
										   userInfo: nil
											repeats: NO
			 ];
		}
    }
    return self;
}


- (void) showActionSheet: (NSTimer *) t {
	[t invalidate];
	
	actionSheet = [[UIActionSheet alloc]
				   initWithTitle: @"How do We Save the Economy??"
				   delegate: self
				   cancelButtonTitle: @"Cancel"
				   destructiveButtonTitle: @"End of the World!"
				   otherButtonTitles:
				   @"Print More Money!",
				   @"Move to Canada?",
				   @"Do nothing",
				   nil
				   ];
	
	[actionSheet showInView: self];
}

- (void) actionSheet: (UIActionSheet *) a
clickedButtonAtIndex: (NSInteger) buttonIndex {
	
	if (a == actionSheet) {
		switch (buttonIndex) {
			case actionDestruct:{
				NSURL *url = [NSURL URLWithString:
							  @"http://www.imdb.com/title/tt0120591"
							  ];
				
				UIApplication *app = [UIApplication sharedApplication];
				
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
				break;
			}
				
			case actionQE3: {
				NSURL *url = [NSURL URLWithString:
							  @"http://seekingalpha.com/article/283499-qe3-a-certainty-in-near-term-downside-expected-in-equities-and-commodities"
							  ];
				
				UIApplication *app = [UIApplication sharedApplication];
				
				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
				break;
			}
				
			case actionEvacuate: {
				NSURL *url = [NSURL URLWithString:
							  @"http://www.howtomovetocanada.net"
							  ];
				
				UIApplication *app = [UIApplication sharedApplication];

				if (![app canOpenURL: url]) {
					NSLog(@"Can't open url %@.", url);
					break;
				}
				
				if (![app openURL: url]) {
					NSLog(@"failed to open URL %@", url);
				}
				break;
			}
				
			case actionNothing:
				break;
				
			case actionCancel:
				break;
				
			default:
				NSLog(@"action sheet button index == %d", buttonIndex);
				break;
		}
	}
}

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
	CGContextSetRGBFillColor(UIGraphicsGetCurrentContext(), 1.0, 1.0, 1.0, 1.0);
	UIFont *f = [UIFont fontWithName: @"Arial" size: 27];
	NSString *s = viewController.text;
	[s drawAtPoint: CGPointMake(0,0) withFont: f];
}


- (void)dealloc {
    [super dealloc];
}


@end
