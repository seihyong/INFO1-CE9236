//
//  View.h
//  Last
//
//  Created by SEI-HYONG PARK on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class ViewController;

@interface View : UIView <UIActionSheetDelegate>{
	ViewController *viewController;
	
	UIActionSheet *actionSheet;
}

-(id) initWithFrame: (CGRect) frame controller: (ViewController *) c;
@end
