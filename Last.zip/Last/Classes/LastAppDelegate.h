//
//  LastAppDelegate.h
//  Last
//
//  Created by SEI-HYONG PARK on 8/8/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LastAppDelegate : NSObject <UIApplicationDelegate> {
    UITabBarController *tabBarController;
	UIWindow *window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

